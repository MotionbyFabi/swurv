import react from "react";
import './home.css';

const Home = () => {
    return (
        <div class="header1">
            <h1>SWURV</h1>
            <p>Motion Designer</p>
        </div>
    );
  }
  
export default Home;